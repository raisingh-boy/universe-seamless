import * as d3Force from "d3-force";
import { GraphData, GraphNode } from "./types";

export function runForceSimulation(
  data: GraphData,
  width: number,
  height: number
): GraphNode[] {
  const nodes: any[] = data.nodes.map((n) => ({ ...n }));
  const edges = data.edges.map((e) => ({
    source: e.source,
    target: e.target,
  }));

  const simulation = d3Force
    .forceSimulation(nodes)
    .force(
      "link",
      d3Force
        .forceLink(edges)
        .id((d: any) => d.id)
        .distance(20)
        .strength(1.0)
    )
    .force("charge", d3Force.forceManyBody().strength(-20))
    .force("collision", d3Force.forceCollide().radius(4))
    .alphaDecay(0.03)
    .stop();

  // Run simulation synchronously
  const iterations = 800;
  for (let i = 0; i < iterations; i++) {
    simulation.tick();
  }

  // Add Z dimension from noise and scale everything down
  const SCALE = 0.3;
  nodes.forEach((n: any, i: number) => {
    n.x *= SCALE;
    n.y *= SCALE;
    n.z = ((Math.sin(i * 2.3) * 1.5 + Math.cos(i * 1.7) * 1.5) * 6) * SCALE;
  });

  return nodes;
}
