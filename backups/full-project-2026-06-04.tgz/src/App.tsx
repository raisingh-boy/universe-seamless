import Scene from "./components/Scene";

function App() {
  return (
    <div style={{ width: "100%", height: "100%" }}>
      {/* Top-left title */}
      <div
        style={{
          position: "absolute",
          top: 32,
          left: 40,
          zIndex: 10,
          pointerEvents: "none",
        }}
      >
        <div
          style={{
            fontFamily: "'Inter', system-ui, sans-serif",
            fontSize: 11,
            fontWeight: 600,
            color: "#d4a857",
            letterSpacing: 5,
            textTransform: "uppercase",
          }}
        >
          Semantic Journey
        </div>
        <div
          style={{
            fontFamily: "'Inter', system-ui, sans-serif",
            fontSize: 9,
            fontWeight: 300,
            color: "rgba(255,255,235,0.3)",
            letterSpacing: 3,
            marginTop: 4,
          }}
        >
          Modern Dance
        </div>
      </div>

      {/* Bottom hint */}
      <div
        style={{
          position: "absolute",
          bottom: 32,
          left: "50%",
          transform: "translateX(-50%)",
          zIndex: 10,
          pointerEvents: "none",
          textAlign: "center",
        }}
      >
        <div
          style={{
            fontFamily: "'Inter', system-ui, sans-serif",
            fontSize: 10,
            color: "rgba(255,255,235,0.15)",
            letterSpacing: 3,
            textTransform: "uppercase",
          }}
        >
          click & drag to explore &bull; scroll to zoom
        </div>
      </div>

      <Scene />
    </div>
  );
}

export default App;
